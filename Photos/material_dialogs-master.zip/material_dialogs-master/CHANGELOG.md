## [1.1.3]
- adding `dialogWidth` in order to support flexible dialogue width

## [1.1.2]
- allow returning values in on close
- update dependencies

## [1.1.1]
- fix bugs

## [1.1.0]
# Breakout changes:
- remove `animation`, `frameRate`, `reverse` and replace it with `lottieBuilder` 
# New features
- add on close callback
- adding custom view, in case you wanted to use only image or different size animations.


## [1.0.0]
- Migrate to Sound null safety
- remove deprecated code

## [0.1.5]
- Update dependencies

## [0.1.4]
- Adding Custom widget in case anyone needs to replace the animation 
with a custom view 
- Update dependencies

## [0.1.3]
- Adding barrier dismissible

## [0.1.2]
- Fixing bottom dialog null frame rate bug


## [0.1.1]
- Fixing some bugs

## [0.1.0]
- Adding animationFrameRate
- Adding animationRepeat
- Adding animationAnimate
- Adding animationReverse



## [0.0.6+1]
-allow custom padding on both IconsButton and OutlinedIconsButton


## [0.0.6]
-mark title and msg variables as not required

## [0.0.5]
- allow only description dialogs
- allow only titles dialogs
- allow only buttons dialogs

## [0.0.4] 
- adding RTL layouts support

## [0.0.3+1] 
- edit examples

## [0.0.3] 
- breakout changes
- use actions widgets list to add buttons.
- add out of the box customized buttons widgets.


## [0.0.2]
- fix single button padding bug and edit ReadMe.

## [0.0.1] 
- first release.
